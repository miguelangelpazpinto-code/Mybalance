package com.mibalance.app;
import java.time.*;
public class Subscription {
 public long id,cents;public String name="",frequency="mensual",date=LocalDate.now().toString();public int anchor=LocalDate.now().getDayOfMonth();public boolean active=true;
 public String nextDate(){LocalDate d=LocalDate.parse(date);if(frequency.equals("semanal"))return d.plusWeeks(1).toString();if(frequency.equals("anual")){YearMonth m=YearMonth.from(d).plusYears(1);return m.atDay(Math.min(anchor,m.lengthOfMonth())).toString();}YearMonth m=YearMonth.from(d).plusMonths(1);return m.atDay(Math.min(anchor,m.lengthOfMonth())).toString();}
 public double monthlyCents(){return !active?0:frequency.equals("anual")?cents/12.0:frequency.equals("semanal")?cents*52.0/12:cents;}
}

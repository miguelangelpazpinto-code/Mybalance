package com.mibalance.app;
import java.util.*;
import java.util.regex.*;
import java.time.*;
import java.math.BigDecimal;

public class Parser {
 public static class Item { public long id, cents; public String date,description,category="Otros",type="gasto",source="Manual",raw=""; public boolean pending=false; }
 static final Pattern AMOUNT=Pattern.compile("(?<![\\d/])[-+]?\\(?\\$?\\s*\\d+(?:[,.]\\d{3})*[.,]\\d{2}\\)?(?!\\d)");
 static final Pattern DATE=Pattern.compile("\\b(\\d{4}-\\d{2}-\\d{2}|\\d{1,2}[/]\\d{1,2}(?:[/]\\d{2,4})?)\\b");
 public static long cents(String text) {
  String s=text.replaceAll("[^0-9,.-]",""); int dot=s.lastIndexOf('.'),comma=s.lastIndexOf(',');
  if(comma>dot) s=s.replace(".","").replace(',','.'); else s=s.replace(",","");
  return new BigDecimal(s).abs().movePointRight(2).longValueExact();
 }
 public static String category(String text) {
  String s=text.toLowerCase(Locale.ROOT);
  if(s.matches(".*(received from|payment received|deposit|direct deposit|payroll|salary|refund|reembolso|abono|income|credited|pago recibido|dinero recibido).*")) return "Ingresos";
  if(s.matches(".*(zelle|venmo|cash app|transfer|traspaso|transferencia).*")) return "Transferencias";
  if(s.matches(".*(walmart|kroger|aldi|supermerc|costco|grocery|heb|target).*")) return "Supermercado";
  if(s.matches(".*(amazon|ebay|etsy|shop|store|best buy|paypal|pago con tarjeta|card purchase).*")) return "Compras";
  if(s.matches(".*(shell|chevron|exxon|gasolina|fuel|uber|lyft).*")) return "Transporte";
  if(s.matches(".*(rent|renta|alquiler|apartment|mortgage).*")) return "Vivienda";
  if(s.matches(".*(electric|internet|water bill|utility|t-mobile|at&t|verizon|comcast).*")) return "Servicios";
  if(s.matches(".*(restaurant|mcdonald|starbucks|doordash|ubereats|comida).*")) return "Comida";
  if(s.matches(".*(pharmacy|cvs|walgreens|hospital|doctor|medical).*")) return "Salud";
  if(s.matches(".*(netflix|spotify|hulu|disney|apple music).*")) return "Suscripciones";
  return "Otros";
 }
 public static String type(String text) {
  String s=text.toLowerCase(Locale.ROOT);
  boolean incoming=s.matches(".*(zelle|venmo|cash app|deposit|depósito|direct deposit|payroll|salary|refund|reembolso|abono|pago recibido|dinero recibido|payment received|received from|credited|income).*" );
  boolean outgoing=s.matches(".*(sent to|send money|enviado a|withdrawal|retiro|debit|purchase|compr(a|ó)|card purchase|pago con tarjeta|merchant|amazon|walmart|paypal|bill pay|payment to).*");
  boolean transfer=s.matches(".*(transfer|traspaso|transferencia).*");
  // Incoming Zelle/deposits are income. Outgoing transfers are expenses. Ambiguous transfers stay neutral.
  if(incoming && !s.matches(".*(payment to|bill pay|sent to|enviado a|withdrawal|debit).*")) return "ingreso";
  if(transfer && s.matches(".*(sent to|send|enviado|outgoing|debit).*")) return "gasto";
  if(transfer && s.matches(".*(received transfer|transfer received|incoming transfer|transfer from|transfer in|transferencia recibida|transferencia de|transferencia entrante).*")) return "ingreso";
  if(transfer) return "transferencia";
  if(outgoing) return "gasto";
  return "gasto";
 }
 public static List<Item> parse(String text,String source,boolean usDates,int year) {
  ArrayList<Item> out=new ArrayList<>();
  String[] lines=text.split("\\r?\\n");
  for(int idx=0;idx<lines.length;idx++) {
   String line=lines[idx].trim(); if(line.isEmpty()) continue;
   String lower=line.toLowerCase(Locale.ROOT);
   if(lower.matches(".*(beginning balance|ending balance|opening balance|closing balance|saldo inicial|saldo final|total deposits|total withdrawals|total credits|total debits|available balance|saldo disponible|current balance|statement balance).*")) continue;
   Matcher m=AMOUNT.matcher(DATE.matcher(line).replaceAll(" ")); ArrayList<String> amounts=new ArrayList<>(); while(m.find()) amounts.add(m.group());
   // If OCR split the description and amount across adjacent lines, combine them.
   if(amounts.isEmpty() && idx+1<lines.length){String next=lines[idx+1].trim();Matcher nm=AMOUNT.matcher(DATE.matcher(next).replaceAll(" "));if(nm.find() && !next.toLowerCase(Locale.ROOT).matches(".*(balance|saldo|total).*")){line=line+" "+next;lower=line.toLowerCase(Locale.ROOT);m=AMOUNT.matcher(DATE.matcher(line).replaceAll(" "));while(m.find())amounts.add(m.group());}}
   if(amounts.isEmpty()) continue;
   Item item=new Item(); item.raw=line; item.source=source; item.description=line.trim();
   try {for(String amount:amounts){item.cents=cents(amount);if(item.cents>0)break;}} catch(Exception e) {continue;}
   if(item.cents<=0) continue;
   item.date=""; Matcher d=DATE.matcher(line);
   if(d.find()) { try {
    String ds=d.group(); String[] p=ds.split("[/.-]"); int y=year,mm,dd;
    if(p[0].length()==4){y=Integer.parseInt(p[0]);mm=Integer.parseInt(p[1]);dd=Integer.parseInt(p[2]);}
    else {mm=Integer.parseInt(p[usDates?0:1]);dd=Integer.parseInt(p[usDates?1:0]);if(p.length==3){y=Integer.parseInt(p[2]);if(y<100)y+=2000;}}
    item.date=LocalDate.of(y,mm,dd).toString();
   }catch(Exception ignored){} }
   if(source.startsWith("Aviso")) item.date=LocalDate.now().toString();
   item.type=type(line); item.category=item.type.equals("ingreso")?"Ingresos":item.type.equals("transferencia")?"Transferencias":category(line);
   out.add(item);
  }
  return out;
 }
}

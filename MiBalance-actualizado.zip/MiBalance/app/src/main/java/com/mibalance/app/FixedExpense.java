package com.mibalance.app;
public class FixedExpense { public long id,cents; public String name="",category="Vivienda"; public int dueDay=1; public boolean active=true; }

package com.mibalance.app;
import org.junit.Test;import static org.junit.Assert.*;
public class FeaturesTest {
 @Test public void receiptSavesTotalNotSubtotalOrCash(){Parser.Item i=ReceiptParser.parse("WALMART\n09/22/2025\nSubtotal 20.00\nTax 1.65\nTOTAL $21.65\nCash 50.00\nChange 28.35",true);assertEquals(2165,i.cents);assertEquals("2025-09-22",i.date);assertEquals("Supermercado",i.category);assertFalse(i.pending);}
 @Test public void uncertainReceiptsNeedReview(){assertTrue(ReceiptParser.parse("WALMART\nTOTAL 20.00",true).pending);assertTrue(ReceiptParser.parse("WALMART\n09/22/2025\nTOTAL 20.00\nTOTAL 21.00",true).pending);assertTrue(ReceiptParser.parse("WALMART\n09/22/2025\nTOTAL EUR 20.00",true).pending);assertTrue(ReceiptParser.parse("DINER\n09/22/2025\nTOTAL 20.00\nTIP _____",true).pending);}
 @Test public void datePreference(){assertEquals("2025-12-09",ReceiptParser.parse("ALDI\n09/12/2025\nTOTAL 10.00",false).date);}
 @Test public void monthEndDoesNotDrift(){Subscription s=new Subscription();s.date="2026-01-31";s.anchor=31;assertEquals("2026-02-28",s.nextDate());s.date=s.nextDate();assertEquals("2026-03-31",s.nextDate());}
 @Test public void annualLeapAndWeekly(){Subscription s=new Subscription();s.frequency="anual";s.date="2024-02-29";s.anchor=29;assertEquals("2025-02-28",s.nextDate());s.frequency="semanal";s.date="2026-12-28";assertEquals("2027-01-04",s.nextDate());}
 @Test public void pausedExcludedFromEstimate(){Subscription s=new Subscription();s.frequency="anual";s.cents=12000;assertEquals(1000,s.monthlyCents(),0.01);s.active=false;assertEquals(0,s.monthlyCents(),0.01);}
}

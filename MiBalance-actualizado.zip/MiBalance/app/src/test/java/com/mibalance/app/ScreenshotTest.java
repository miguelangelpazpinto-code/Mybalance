package com.mibalance.app;
import org.junit.Test;import static org.junit.Assert.*;import java.util.*;
public class ScreenshotTest {
 @Test public void mixedScreenshotRows(){List<Parser.Item> items=Parser.parse("09/01/2025 Walmart -$23.45\n09/02/2025 Payment received $120.00\n09/03/2025 Pago recibido $70.00", "Foto o captura",true,2025);assertEquals(3,items.size());assertEquals("gasto",items.get(0).type);assertEquals("ingreso",items.get(1).type);assertEquals("ingreso",items.get(2).type);assertTrue(items.get(1).pending);assertEquals("Foto o captura",items.get(1).source);}
 @Test public void positiveAmountAndOwnTransfer(){assertEquals("ingreso",Parser.parse("09/02/2025 ACME +$120.00","Foto o captura",true,2025).get(0).type);assertEquals("transferencia",Parser.parse("09/02/2025 Transfer +$120.00","Foto o captura",true,2025).get(0).type);}
}
